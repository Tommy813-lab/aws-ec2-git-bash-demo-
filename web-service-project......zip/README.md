# Web Service Project – EC2 Deployment via Git Bash & GitHub

## Overview

This project shows how to deploy a basic web service to an AWS EC2 instance using Git Bash on Windows and GitHub. It proves I understand core cloud deployment concepts, Git usage, and remote Linux server management.

---

## Tech Used

- AWS EC2 (Ubuntu 22.04)
- Git Bash (Windows)
- Git + GitHub
- Node.js (for backend server)
- Python HTTP Server (as alternative)
- SSH for remote access

---

## EC2 Deployment Steps

### Step 1: Connect to EC2 via Git Bash
```bash
ssh -i ~/.ssh/ec2-key.pem ubuntu@<your-ec2-ip>
```

### Step 2: Clone This Repo on EC2
```bash
sudo apt update
sudo apt install git -y
git clone https://github.com/Tommy813-lab/web-service-project.git
cd web-service-project
```

---

## Backend Server (Node.js)

### Install Node.js
```bash
sudo apt install nodejs npm -y
```

### Run the App
```bash
cd src/backend
npm install
node app.js
```

Then go to: `http://<your-ec2-ip>:3000`

---

## Static Page (Optional Python Version)

```bash
cd src/static
python3 -m http.server 3000
```

Then visit: `http://<your-ec2-ip>:3000` in your browser.

---

## File Structure

```
web-service-project/
├── README.md
├── src/
│   ├── backend/
│   │   ├── app.js
│   │   └── package.json
│   └── static/
│       └── index.html
└── screenshots/
    └── ec2-connected.png
```

---

## Screenshots

| Connected to EC2 | Web App Live |
|------------------|--------------|
| ![](./screenshots/ec2-connected.png) | ![](./screenshots/app-running.png) |

---

## Next Steps

- Add NGINX reverse proxy and domain name
- Secure with HTTPS (Let’s Encrypt)
- Create a deployment shell script
- Try deploying with Docker next

---

## Author

GitHub: [Tommy813-lab](https://github.com/Tommy813-lab)
